const express =require("express");
require('dotenv').config();

const app =express();
app.use(express.json());
const router=require("./router/auth-router");
const connectDB=require("./utils/db")

app.use("/api/auth",router)






const PORT=5000;
connectDB().then(()=>{
  app.listen(PORT,()=>{
    console.log(`server is runniing at port ${PORT} `);
  })
});
