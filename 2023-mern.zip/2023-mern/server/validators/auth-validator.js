const {z}=require("zod");
//  creating schame


const signupSchema= z.object({
  username:z
  .string({required_error:"Name is Required"})
  .trim()
  .min(3,{message:"name must be at least of 3 chars"})
  .max(255,{message:"name not more then 255 characters"}),

  email:z
  .string({required_error:"email is Required"})
  .trim()
  .email({message:"invalid email"})
  .min(3,{message:"invalide email address"})
  .max(255,{message:"email does not more than 255 word"}), 

  phone:z
  .string({required_error:"phone is Required"})
  .trim()
  .min(10,{message:"phone must be required"})
  .max(20,{message:"phone not more then 255 characters"}),

   password:z
   .string({required_error:"password is Required"})
   .trim()
   .min(7,{message:"password must be at least of 7 chars"})
   .max(255,{message:"name not more then 255 characters"}),
});
module.exports=signupSchema;


